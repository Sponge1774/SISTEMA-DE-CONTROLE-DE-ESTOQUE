# Roteiro — Vídeo Pitch (Teleprompter)

**Sistema de Controle de Estoque | Duração: 3:30**

Instruções: os quadros em negrito indicam **O QUE FAZER** na tela; o texto entre
aspas é **O QUE FALAR**.

## 1. Abertura e proposta (0:00 – 0:30)

**AÇÃO NA TELA:** Rosto do apresentador na câmera.

"Olá! Meu nome é Eduardo Souza Mattos, e este é o meu projeto para a disciplina
Development with Python, do Centro Universitário UniFECAF: um Sistema de
Controle de Estoque."

"Muitas empresas ainda controlam o estoque em planilhas ou papel, gerando erros
e perda de tempo."

"Por isso, desenvolvi uma aplicação em Python que resolve isso de duas formas:
ela roda como um programa de desktop, usando Tkinter, e também como uma
página web, usando Flask. Ambas ficam sempre sincronizadas."

## 2. Estrutura do código (0:30 – 1:00)

**AÇÃO NA TELA:** Abrir o VS Code com a estrutura de pastas do projeto visível
(`database/`, `models/`, `ui/`, `templates/`).

"O código está muito bem organizado."

"Na pasta `database` fica o banco SQLite e as tabelas."

"Na pasta `models` estão as regras de negócio e validações. Tanto a interface
desktop quanto a web chamam exatamente as mesmas funções daqui, evitando
duplicação."

"Por fim, a pasta `ui` guarda as telas Tkinter, e o arquivo `webapp.py` com os
templates gerencia a interface web."

## 3. Demonstração no Desktop — Tkinter (1:00 – 2:00)

**AÇÃO NA TELA:** Rodar `python3 main.py` e fazer login (`admin`/`admin123`).

"Vou rodar a versão de computador. Faço login como administrador..."

**AÇÃO NA TELA:** Clicar em "Novo Fornecedor" e cadastrar a "Distribuidora ABC".

"...cadastro o fornecedor Distribuidora ABC..."

**AÇÃO NA TELA:** Clicar em "Novo Produto": Banana, categoria Alimentos,
fornecedor Distribuidora ABC, quantidade 100, mínima 50, preço R$ 20,00. Salvar.

"...e em seguida um produto: Banana, categoria Alimentos, cem unidades e mínimo
de cinquenta. O sistema gera um código único automaticamente, o `PRD-A23QEX`."

**AÇÃO NA TELA:** Selecionar a Banana, clicar em "Registrar Saída", informar 60.

"Se eu simular uma saída de sessenta unidades, o estoque fica abaixo do mínimo e
o sistema destaca o produto em vermelho na listagem."

## 4. Demonstração no Navegador — Flask e a sincronização (2:00 – 3:05)

**AÇÃO NA TELA:** Em outro terminal, rodar `python3 webapp.py` e abrir
`127.0.0.1:5000` no navegador. Fazer login.

"Agora, o grande diferencial: abro um segundo terminal e rodo a versão web,
acessando pelo navegador com o mesmo login."

**AÇÃO NA TELA:** Mostrar o dashboard web com a Banana e o alerta vermelho,
comparando com a tela do Tkinter.

"E vejam: a Banana cadastrada no desktop já aparece aqui, com o mesmo código,
quantidade e o alerta vermelho de estoque baixo, provando que compartilham o
mesmo banco de dados."

**AÇÃO NA TELA:** Clicar em "Relatórios" e baixar o CSV ou Excel.

"Também é possível gerar relatórios em CSV ou Excel direto pelo navegador."

## 5. Encerramento (3:05 – 3:30)

**AÇÃO NA TELA:** Retornar para a câmera ou tela final do projeto.

"Esse projeto me permitiu aplicar conceitos de banco de dados, regras de
negócio e múltiplos tipos de interface em Python."

"Como próximo passo, pretendo evoluir para tempo real usando WebSockets,
conforme documentado no relatório."

"Muito obrigado por assistir!"
