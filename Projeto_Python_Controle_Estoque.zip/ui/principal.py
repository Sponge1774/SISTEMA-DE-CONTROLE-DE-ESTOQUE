"""
ui/principal.py
================================================================
Camada de interface (view) responsável pela TELA PRINCIPAL da
aplicação: listagem de estoque, cadastro de produto (agora com
categoria e fornecedor relacionados), registro de movimentações
(entrada/saída, já guardando o preço histórico), cadastro de
fornecedores e, quando o usuário é admin, cadastro de novos
usuários.

Assim como em login.py, esta tela apenas coleta dados e delega
toda a lógica de validação/gravação para os models.
================================================================
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog  # filedialog abre a janela nativa "Salvar como..."

from models.produto import cadastrar_produto, listar_produtos, registrar_movimentacao
from models.usuario import cadastrar_usuario
from models.categoria import listar_categorias
from models.fornecedor import listar_fornecedores, cadastrar_fornecedor
from models.relatorio import gerar_relatorio_estoque, gerar_relatorio_movimentacoes


class TelaPrincipal(tk.Tk):
    def __init__(self, usuario):
        """
        Parâmetro:
            usuario: a linha (sqlite3.Row) do usuário autenticado,
            recebida da tela de login. Guardamos essa referência
            em self.usuario porque ela é usada em vários pontos:
            - para exibir o nome/perfil no título da janela;
            - para saber se deve ou não mostrar o botão de
              "Cadastrar Usuário" (somente perfil admin);
            - para registrar QUEM fez cada movimentação de
              estoque (rastreabilidade — requisito "j. Sessão de
              usuário").
        """
        super().__init__()
        self.usuario = usuario
        self.title(f"Controle de Estoque — {usuario['nome']} ({usuario['perfil']})")
        self.geometry("900x480")

        self._montar_menu()   # monta a barra de botões no topo
        self._montar_lista()  # monta a tabela de produtos
        self.atualizar_lista()  # já carrega os dados do banco assim que a tela abre

    # ============================================================
    # MENU / BARRA DE BOTÕES
    # ============================================================
    def _montar_menu(self):
        barra = tk.Frame(self, pady=8)
        barra.pack(fill="x")

        tk.Button(barra, text="Novo Produto", command=self.abrir_cadastro_produto).pack(side="left", padx=5)
        tk.Button(barra, text="Novo Fornecedor", command=self.abrir_cadastro_fornecedor).pack(side="left", padx=5)
        tk.Button(barra, text="Registrar Entrada", command=lambda: self.abrir_movimentacao("entrada")).pack(side="left", padx=5)
        tk.Button(barra, text="Registrar Saída", command=lambda: self.abrir_movimentacao("saida")).pack(side="left", padx=5)
        tk.Button(barra, text="Atualizar Lista", command=self.atualizar_lista).pack(side="left", padx=5)
        tk.Button(barra, text="Gerar Relatório", command=self.abrir_gerar_relatorio).pack(side="left", padx=5)

        # Este botão SÓ é criado se o perfil do usuário logado for
        # 'admin' — requisito "Somente administrador poderá
        # cadastrar usuário".
        if self.usuario["perfil"] == "admin":
            tk.Button(barra, text="Cadastrar Usuário", command=self.abrir_cadastro_usuario).pack(side="left", padx=5)

    # ============================================================
    # LISTAGEM (TABELA DE PRODUTOS)
    # ============================================================
    def _montar_lista(self):
        """
        Cria a tabela (Treeview) que exibe os produtos, agora
        incluindo as colunas "Categoria" e "Fornecedor" (antes só
        existia "Categoria" como texto livre; agora ambas vêm dos
        LEFT JOIN feitos em models/produto.py -> listar_produtos()).
        """
        colunas = ("id", "nome", "codigo", "categoria", "fornecedor", "quantidade", "minimo", "preco")
        self.tree = ttk.Treeview(self, columns=colunas, show="headings")

        titulos = {
            "id": "ID", "nome": "Nome", "codigo": "Código", "categoria": "Categoria",
            "fornecedor": "Fornecedor", "quantidade": "Qtd. Atual", "minimo": "Qtd. Mínima",
            "preco": "Preço Unit.",
        }
        larguras = {"nome": 130, "fornecedor": 130, "categoria": 100}
        for c in colunas:
            self.tree.heading(c, text=titulos[c])
            self.tree.column(c, width=larguras.get(c, 90), anchor="center")

        # Tag de destaque visual para produtos com estoque abaixo
        # do mínimo (requisito de alerta).
        self.tree.tag_configure("alerta", background="#f8d7da")

        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

    def atualizar_lista(self):
        """
        Recarrega a tabela com os dados mais recentes do banco,
        incluindo o nome da categoria e do fornecedor (que agora
        vêm de tabelas relacionadas, não mais de texto livre).
        """
        for item in self.tree.get_children():
            self.tree.delete(item)

        for p in listar_produtos():
            tag = "alerta" if p["quantidade_atual"] < p["quantidade_minima"] else ""
            self.tree.insert("", "end", values=(
                p["id_produto"], p["nome"], p["codigo"],
                p["categoria_nome"] or "-", p["fornecedor_nome"] or "-",
                p["quantidade_atual"], p["quantidade_minima"], f"R$ {p['preco_unitario']:.2f}",
            ), tags=(tag,))

    def _produto_selecionado(self):
        selecao = self.tree.selection()
        if not selecao:
            return None
        return self.tree.item(selecao[0])["values"]

    # ============================================================
    # JANELA: CADASTRO DE PRODUTO
    # ============================================================
    def abrir_cadastro_produto(self):
        """
        Formulário de cadastro de produto, agora com:
        - Combobox EDITÁVEL de categoria: o usuário pode escolher
          uma categoria já existente na lista, OU digitar um nome
          novo — nesse caso, models/categoria.py cria a categoria
          automaticamente ao salvar (função obter_ou_criar_categoria);
        - Combobox SOMENTE LEITURA de fornecedor: como fornecedor
          exige dados completos (CNPJ), ele precisa ser cadastrado
          antes, pelo botão "Novo Fornecedor"; aqui só é possível
          selecionar um já existente (ou deixar "Nenhum").
        """
        janela = tk.Toplevel(self)
        janela.title("Novo Produto")
        janela.geometry("340x380")
        janela.grab_set()

        tk.Label(
            janela, text="O código do produto será gerado\nautomaticamente ao salvar.",
            fg="gray", justify="center",
        ).grid(row=0, column=0, columnspan=2, pady=(10, 5))

        campos = {}
        rotulos_texto = [
            ("nome", "Nome*"), ("quantidade_inicial", "Qtd. Inicial*"),
            ("quantidade_minima", "Qtd. Mínima*"), ("preco_unitario", "Preço Unitário*"),
        ]

        # --- Campo Categoria (Combobox editável) ---
        tk.Label(janela, text="Categoria").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        nomes_categorias = [c["nome"] for c in listar_categorias()]
        combo_categoria = ttk.Combobox(janela, values=nomes_categorias)  # editável por padrão (sem state="readonly")
        combo_categoria.grid(row=1, column=1, padx=5, pady=5)

        # --- Campo Fornecedor (Combobox somente leitura) ---
        tk.Label(janela, text="Fornecedor").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        fornecedores = listar_fornecedores()
        # Guardamos os ids em uma lista paralela na MESMA ordem dos
        # textos exibidos, para conseguir "traduzir" de volta o
        # texto escolhido para o id_fornecedor correspondente.
        opcoes_fornecedor = ["-- Nenhum --"] + [f"{f['nome']} ({f['cnpj']})" for f in fornecedores]
        ids_fornecedor = [None] + [f["id_fornecedor"] for f in fornecedores]
        combo_fornecedor = ttk.Combobox(janela, values=opcoes_fornecedor, state="readonly")
        combo_fornecedor.current(0)  # começa em "-- Nenhum --"
        combo_fornecedor.grid(row=2, column=1, padx=5, pady=5)

        # --- Demais campos numéricos/texto, gerados dinamicamente ---
        for i, (chave, rotulo) in enumerate(rotulos_texto, start=3):
            tk.Label(janela, text=rotulo).grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entrada = tk.Entry(janela)
            entrada.grid(row=i, column=1, padx=5, pady=5)
            campos[chave] = entrada

        def salvar():
            try:
                # Traduz o texto escolhido no combobox de fornecedor
                # de volta para o id_fornecedor correspondente (ou
                # None, se "-- Nenhum --" estiver selecionado).
                indice = combo_fornecedor.current()
                id_fornecedor = ids_fornecedor[indice] if indice >= 0 else None

                codigo_gerado = cadastrar_produto(
                    campos["nome"].get().strip(),
                    combo_categoria.get().strip(),
                    id_fornecedor,
                    campos["quantidade_inicial"].get(),
                    campos["quantidade_minima"].get(),
                    campos["preco_unitario"].get(),
                )
                messagebox.showinfo("Sucesso", f"Produto cadastrado com sucesso!\nCódigo gerado: {codigo_gerado}")
                janela.destroy()
                self.atualizar_lista()
            except ValueError as erro:
                messagebox.showerror("Erro de validação", str(erro))
            except Exception:
                messagebox.showerror("Erro", "Código de produto já existente ou dado inválido.")

        tk.Button(janela, text="Salvar", command=salvar).grid(
            row=3 + len(rotulos_texto), column=0, columnspan=2, pady=15
        )

    # ============================================================
    # JANELA: CADASTRO DE FORNECEDOR (NOVA)
    # ============================================================
    def abrir_cadastro_fornecedor(self):
        """
        Cadastro de fornecedor, aberto a qualquer usuário logado
        (não é restrito ao admin — diferente do cadastro de
        usuário do sistema). Depois de cadastrado, o fornecedor
        passa a aparecer no combobox de "Novo Produto".
        """
        janela = tk.Toplevel(self)
        janela.title("Novo Fornecedor")
        janela.geometry("300x220")
        janela.grab_set()

        campos = {}
        for i, (chave, rotulo) in enumerate([("nome", "Nome*"), ("cnpj", "CNPJ*"), ("telefone", "Telefone")]):
            tk.Label(janela, text=rotulo).grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entrada = tk.Entry(janela)
            entrada.grid(row=i, column=1, padx=5, pady=5)
            campos[chave] = entrada

        def salvar():
            try:
                cadastrar_fornecedor(
                    campos["nome"].get().strip(),
                    campos["cnpj"].get().strip(),
                    campos["telefone"].get().strip(),
                )
                messagebox.showinfo("Sucesso", "Fornecedor cadastrado com sucesso.")
                janela.destroy()
            except ValueError as erro:
                messagebox.showerror("Erro de validação", str(erro))
            except Exception:
                # Erro mais comum aqui: CNPJ duplicado (coluna UNIQUE).
                messagebox.showerror("Erro", "CNPJ já cadastrado para outro fornecedor.")

        tk.Button(janela, text="Salvar", command=salvar).grid(row=3, column=0, columnspan=2, pady=15)

    # ============================================================
    # JANELA: REGISTRAR ENTRADA / SAÍDA (MOVIMENTAÇÃO)
    # ============================================================
    def abrir_movimentacao(self, tipo):
        """
        O preço unitário do produto é capturado automaticamente
        pelo model (registrar_movimentacao), sem precisar de mais
        nenhum campo aqui na tela — ele "fotografa" o preço atual
        do produto no instante da movimentação.
        """
        produto = self._produto_selecionado()
        if not produto:
            messagebox.showwarning("Seleção necessária", "Selecione um produto na lista.")
            return

        janela = tk.Toplevel(self)
        titulo = "Registrar Entrada" if tipo == "entrada" else "Registrar Saída"
        janela.title(titulo)
        janela.geometry("300x180")
        janela.grab_set()

        # produto[1] é o "nome" do produto (colunas definidas em
        # _montar_lista: id=0, nome=1, codigo=2, categoria=3, ...).
        tk.Label(janela, text=f"Produto: {produto[1]}", font=("Segoe UI", 10, "bold")).pack(pady=(15, 5))
        tk.Label(janela, text="Quantidade*").pack()
        entrada_qtd = tk.Entry(janela)
        entrada_qtd.pack(pady=5)
        tk.Label(janela, text="Observação").pack()
        entrada_obs = tk.Entry(janela)
        entrada_obs.pack(pady=5)

        def salvar():
            try:
                registrar_movimentacao(
                    produto[0], self.usuario["id_usuario"], tipo,
                    entrada_qtd.get(), entrada_obs.get().strip(),
                )
                messagebox.showinfo("Sucesso", "Movimentação registrada com sucesso.")
                janela.destroy()
                self.atualizar_lista()
            except ValueError as erro:
                messagebox.showerror("Erro de validação", str(erro))

        tk.Button(janela, text="Confirmar", command=salvar).pack(pady=10)

    # ============================================================
    # JANELA: GERAR RELATÓRIO (NOVA)
    # ============================================================
    def abrir_gerar_relatorio(self):
        """
        Permite ao usuário escolher QUAL relatório exportar
        (estoque atual ou histórico de movimentações) e em QUAL
        formato (CSV ou Excel), usando pandas nos bastidores
        (models/relatorio.py) — conteúdo estudado na Unidade III
        da disciplina ("Exportação de Arquivos").

        Fluxo:
        1) o usuário escolhe o tipo de relatório em um combobox;
        2) ao clicar em "Gerar", abrimos a janela NATIVA do sistema
           operacional "Salvar como..." (filedialog), para que o
           usuário escolha ONDE salvar e o NOME do arquivo;
        3) chamamos a função correspondente do model, que decide
           entre CSV/Excel de acordo com a extensão escolhida.
        """
        janela = tk.Toplevel(self)
        janela.title("Gerar Relatório")
        janela.geometry("320x200")
        janela.grab_set()

        tk.Label(janela, text="Tipo de relatório*").grid(row=0, column=0, sticky="e", padx=5, pady=(20, 5))
        tipo_var = tk.StringVar(value="Estoque atual")
        ttk.Combobox(
            janela, textvariable=tipo_var,
            values=["Estoque atual", "Histórico de movimentações"],
            state="readonly", width=22,
        ).grid(row=0, column=1, padx=5, pady=(20, 5))

        tk.Label(janela, text="Formato do arquivo*").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        formato_var = tk.StringVar(value="CSV (.csv)")
        ttk.Combobox(
            janela, textvariable=formato_var,
            values=["CSV (.csv)", "Excel (.xlsx)"],
            state="readonly", width=22,
        ).grid(row=1, column=1, padx=5, pady=5)

        def gerar():
            # Traduz a escolha do combobox de formato para a
            # extensão e o filtro que o filedialog deve usar.
            if formato_var.get().startswith("CSV"):
                extensao, filtro = ".csv", [("Arquivo CSV", "*.csv")]
            else:
                extensao, filtro = ".xlsx", [("Arquivo Excel", "*.xlsx")]

            nome_sugerido = (
                "relatorio_estoque" if tipo_var.get() == "Estoque atual"
                else "relatorio_movimentacoes"
            )

            # Abre a janela nativa "Salvar como..." do sistema
            # operacional (funciona igual no Pop!_OS/Linux, Windows
            # e macOS), já sugerindo nome e extensão do arquivo.
            caminho = filedialog.asksaveasfilename(
                parent=janela,
                title="Salvar relatório como...",
                initialfile=nome_sugerido + extensao,
                defaultextension=extensao,
                filetypes=filtro,
            )
            if not caminho:  # usuário clicou em "Cancelar"
                return

            try:
                if tipo_var.get() == "Estoque atual":
                    gerar_relatorio_estoque(caminho)
                else:
                    gerar_relatorio_movimentacoes(caminho)
                messagebox.showinfo("Sucesso", f"Relatório gerado com sucesso em:\n{caminho}")
                janela.destroy()
            except ValueError as erro:
                messagebox.showerror("Erro ao gerar relatório", str(erro))
            except Exception as erro:
                messagebox.showerror("Erro ao gerar relatório", f"Não foi possível salvar o arquivo.\n{erro}")

        tk.Button(janela, text="Gerar", command=gerar).grid(row=2, column=0, columnspan=2, pady=20)

    # ============================================================
    # JANELA: CADASTRO DE USUÁRIO (SOMENTE ADMINISTRADOR)
    # ============================================================
    def abrir_cadastro_usuario(self):
        janela = tk.Toplevel(self)
        janela.title("Novo Usuário")
        janela.geometry("300x260")
        janela.grab_set()

        campos = {}
        for i, (chave, rotulo) in enumerate([("nome", "Nome*"), ("login", "Login*"), ("senha", "Senha*")]):
            tk.Label(janela, text=rotulo).grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entrada = tk.Entry(janela, show="*" if chave == "senha" else None)
            entrada.grid(row=i, column=1, padx=5, pady=5)
            campos[chave] = entrada

        tk.Label(janela, text="Perfil*").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        perfil_var = tk.StringVar(value="comum")
        tk.OptionMenu(janela, perfil_var, "comum", "admin").grid(row=3, column=1, padx=5, pady=5)

        def salvar():
            try:
                cadastrar_usuario(
                    campos["nome"].get().strip(), campos["login"].get().strip(),
                    campos["senha"].get(), perfil_var.get(),
                )
                messagebox.showinfo("Sucesso", "Usuário cadastrado com sucesso.")
                janela.destroy()
            except ValueError as erro:
                messagebox.showerror("Erro de validação", str(erro))
            except Exception:
                messagebox.showerror("Erro", "Login já existente.")

        tk.Button(janela, text="Salvar", command=salvar).grid(row=4, column=0, columnspan=2, pady=15)
