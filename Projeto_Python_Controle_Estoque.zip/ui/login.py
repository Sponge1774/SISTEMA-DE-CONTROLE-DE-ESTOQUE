"""
ui/login.py
================================================================
Camada de interface (view) responsável apenas pela TELA DE LOGIN.
Ela não sabe nada sobre SQL ou hash de senha — apenas coleta o
que o usuário digitou e delega a validação para
models/usuario.py (função autenticar), seguindo o princípio de
separar "interface" de "regra de negócio".
================================================================
"""

import tkinter as tk           # biblioteca gráfica padrão do Python (requisito "g" do enunciado)
from tkinter import messagebox  # sub-módulo do Tkinter para caixas de diálogo (erro, aviso, sucesso)

from models.usuario import autenticar


class TelaLogin(tk.Tk):
    """
    Esta classe HERDA de tk.Tk, ou seja, ELA PRÓPRIA já é a janela
    principal da aplicação (não precisamos criar uma tk.Tk() à
    parte e depois adicionar widgets nela). Herdar de tk.Tk é um
    padrão comum quando a tela de login é a primeira janela do
    programa.
    """

    def __init__(self, ao_autenticar):
        """
        Parâmetros:
            ao_autenticar: uma função (callback) que será chamada
            automaticamente quando o login der certo, recebendo
            como argumento os dados do usuário autenticado. Quem
            decide o que acontece depois do login (abrir a tela
            principal) é o main.py, não esta classe — isso deixa
            a tela de login reutilizável e desacoplada do resto
            do sistema.
        """
        super().__init__()  # inicializa a janela tk.Tk() por trás dos panos
        self.title("Controle de Estoque - Login")
        self.geometry("360x220")   # tamanho fixo da janela (largura x altura em pixels)
        self.resizable(False, False)  # impede que o usuário redimensione a janela de login
        self.ao_autenticar = ao_autenticar

        # --- Título na tela ---
        tk.Label(self, text="Controle de Estoque", font=("Segoe UI", 14, "bold")).pack(pady=(20, 10))

        # --- Área com os campos de login e senha, organizados em grade (grid) ---
        frame = tk.Frame(self)
        frame.pack(pady=5)

        tk.Label(frame, text="Login:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.entry_login = tk.Entry(frame)
        self.entry_login.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frame, text="Senha:").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        # show="*" faz com que os caracteres digitados apareçam
        # como asteriscos na tela, escondendo a senha de quem
        # está olhando por cima do ombro.
        self.entry_senha = tk.Entry(frame, show="*")
        self.entry_senha.grid(row=1, column=1, padx=5, pady=5)

        # --- Botão de ação ---
        tk.Button(self, text="Entrar", width=15, command=self.efetuar_login).pack(pady=15)
        tk.Label(self, text="Usuário padrão: admin / admin123", fg="gray").pack()

        # Permite pressionar a tecla Enter em qualquer lugar da
        # janela para efetuar o login, sem precisar clicar no
        # botão — pequeno detalhe de usabilidade (requisito "e").
        self.bind("<Return>", lambda event: self.efetuar_login())

        # Já deixa o cursor piscando no campo de login ao abrir a tela.
        self.entry_login.focus()

    def efetuar_login(self):
        """
        Chamada quando o usuário clica em "Entrar" ou pressiona Enter.

        Fluxo:
        1) Lê o texto dos campos de login e senha;
        2) Se algum estiver vazio, mostra um aviso e para aqui
           (validação de campo obrigatório, requisito "d");
        3) Chama autenticar(login, senha) do model — que faz o
           hash da senha e consulta o banco;
        4) Se autenticar() devolver None, mostra mensagem de erro
           e mantém a tela de login aberta;
        5) Se dermos certo, fechamos esta janela (self.destroy())
           e chamamos o callback ao_autenticar, passando os dados
           do usuário logado — é esse callback (definido em
           main.py) que abre a tela principal.
        """
        login = self.entry_login.get().strip()   # .strip() remove espaços acidentais no início/fim
        senha = self.entry_senha.get()

        if not login or not senha:
            messagebox.showwarning("Campos obrigatórios", "Informe login e senha.")
            return

        usuario = autenticar(login, senha)
        if usuario is None:
            messagebox.showerror("Erro de autenticação", "Login ou senha inválidos.")
            return

        self.destroy()          # fecha a janela de login
        self.ao_autenticar(usuario)  # "entrega" o usuário autenticado para quem chamou esta tela
