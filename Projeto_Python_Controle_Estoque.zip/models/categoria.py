"""
models/categoria.py
================================================================
Regras de negócio da entidade CATEGORIA, criada para normalizar
o antigo campo de texto livre que existia dentro de PRODUTO.
================================================================
"""

from database.db import get_connection


def listar_categorias():
    """Retorna todas as categorias cadastradas, em ordem alfabética."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM categoria ORDER BY nome")
    dados = cur.fetchall()
    conn.close()
    return dados


def obter_ou_criar_categoria(cur, nome: str):
    """
    Recebe o NOME de uma categoria digitado/selecionado na tela e
    devolve o id_categoria correspondente:
    - Se já existir uma categoria com esse nome (comparação sem
      diferenciar maiúsculas/minúsculas, graças a "COLLATE
      NOCASE"), reaproveita o id existente;
    - Se não existir, cria uma nova categoria na hora e devolve o
      id recém-criado (cur.lastrowid).

    Por que receber "cur" em vez de abrir sua própria conexão?
    Para que a criação da categoria aconteça DENTRO da mesma
    transação do cadastro do produto (veja cadastrar_produto em
    models/produto.py) — se o cadastro do produto falhar por
    qualquer motivo, a categoria recém-criada também não fica
    "presa" no banco sem uso.

    Se o campo vier vazio, devolvemos None (categoria é opcional).
    """
    nome = (nome or "").strip()
    if not nome:
        return None

    cur.execute("SELECT id_categoria FROM categoria WHERE nome = ? COLLATE NOCASE", (nome,))
    linha = cur.fetchone()
    if linha:
        return linha["id_categoria"]

    cur.execute("INSERT INTO categoria (nome) VALUES (?)", (nome,))
    return cur.lastrowid
