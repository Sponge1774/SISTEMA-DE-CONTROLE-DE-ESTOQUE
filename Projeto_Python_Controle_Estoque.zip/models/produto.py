"""
models/produto.py
================================================================
Camada de regras de negócio relacionada a PRODUTO e a
MOVIMENTACAO de estoque. É aqui que ficam as validações de dados
e a lógica de "somar/subtrair" a quantidade em estoque a cada
entrada ou saída registrada.
================================================================
"""

import random
import string

from database.db import get_connection
from models.categoria import obter_ou_criar_categoria


def gerar_codigo_produto(cur) -> str:
    """
    Gera um código de identificação ALEATÓRIO e ÚNICO para um
    novo produto, no formato "PRD-XXXXXX" (6 caracteres
    alfanuméricos maiúsculos após o prefixo, ex.: "PRD-7K2QXB").

    Por que gerar em vez de deixar o usuário digitar?
    - Elimina erro de digitação e códigos "feios"/inconsistentes;
    - Garante, por construção, que nunca existirão dois produtos
      com o mesmo código — requisito pedido pelo usuário.

    Parâmetro:
        cur: um cursor já aberto (reutilizamos a mesma conexão/
             transação de quem chamou esta função, em vez de abrir
             uma conexão nova aqui dentro).

    Como garante que é único:
    1) Sorteia um código aleatório usando letras maiúsculas (A-Z)
       e dígitos (0-9);
    2) Consulta o banco para ver se esse código já existe;
    3) Se já existir (chance extremamente baixa, mas não nula),
       sorteia outro e tenta de novo — um laço "while True" que só
       para quando encontra um código livre.

    Por que 6 caracteres alfanuméricos?
    Com 36 símbolos possíveis (26 letras + 10 números) elevado a
    6 posições, temos mais de 2 bilhões de combinações possíveis
    — mais que suficiente para um sistema de controle de estoque
    nunca esgotar códigos disponíveis.
    """
    caracteres = string.ascii_uppercase + string.digits  # "A".."Z" + "0".."9"
    while True:
        sufixo = "".join(random.choices(caracteres, k=6))
        codigo = f"PRD-{sufixo}"
        cur.execute("SELECT 1 FROM produto WHERE codigo = ?", (codigo,))
        if cur.fetchone() is None:  # código livre, pode usar
            return codigo
        # se caiu aqui, o código sorteado já existe — o laço
        # simplesmente tenta de novo com outro sorteio


def validar_numero(valor: str, campo: str) -> float:
    """
    Tenta converter o texto digitado pelo usuário em um número
    (float). Essa função é o coração do requisito "d. Validações
    nos campos para ele não informar texto no lugar de número"
    do enunciado.

    Parâmetros:
        valor: o texto vindo diretamente de um campo Entry do
               Tkinter (sempre chega como string, mesmo que o
               usuário digite números);
        campo: nome do campo, usado só para montar uma mensagem
               de erro mais clara (ex.: "Quantidade").

    Se a conversão falhar (por exemplo, o usuário digitou "abc"
    em vez de um número), Python lança automaticamente um
    TypeError ou ValueError; nós capturamos esse erro e
    relançamos como uma ValueError com mensagem amigável em
    português, que a tela consegue exibir diretamente em uma
    caixa de diálogo (messagebox).
    """
    try:
        return float(valor)
    except (TypeError, ValueError):
        raise ValueError(f"O campo '{campo}' deve conter um número válido.")


def cadastrar_produto(nome, categoria_nome, id_fornecedor, quantidade_inicial, quantidade_minima, preco_unitario):
    """
    Cadastra um novo produto no estoque.

    Parâmetros novos em relação à versão anterior:
        categoria_nome: texto digitado/selecionado no combobox de
                         categoria. Pode ser uma categoria já
                         existente ou uma nova — obter_ou_criar_
                         categoria() decide isso automaticamente.
                         Pode vir vazio (categoria é opcional).
        id_fornecedor:   id do fornecedor escolhido no combobox
                          (ou None, se "Nenhum" for selecionado).
                          Diferente da categoria, o fornecedor não
                          é criado "na hora" aqui — ele precisa já
                          existir, cadastrado antes pela tela de
                          Fornecedores (dados como CNPJ exigem um
                          cadastro completo, não só um nome livre).

    Observação: o parâmetro "codigo" não é recebido de fora — ele
    é gerado internamente por gerar_codigo_produto(), de forma
    aleatória e garantidamente única, dentro da MESMA transação do
    INSERT (por isso passamos o mesmo "cur" para as duas operações).

    Ordem de validação:
    1) nome é obrigatório;
    2) quantidade_inicial, quantidade_minima e preco_unitario
       passam por validar_numero();
    3) só depois disso resolvemos a categoria (criando se
       necessário) e sorteamos o código, e então executamos o
       INSERT.

    Retorno:
        O código gerado para o produto (string), para que a tela
        possa exibi-lo ao usuário logo após o cadastro.
    """
    if not nome:
        raise ValueError("O nome do produto é obrigatório.")

    quantidade_inicial = int(validar_numero(quantidade_inicial, "Quantidade inicial"))
    quantidade_minima = int(validar_numero(quantidade_minima, "Quantidade mínima"))
    preco_unitario = validar_numero(preco_unitario, "Preço unitário")  # preço pode ter casas decimais

    conn = get_connection()
    cur = conn.cursor()
    try:
        # obter_ou_criar_categoria devolve o id de uma categoria já
        # existente com esse nome, ou cria uma nova na hora — tudo
        # dentro desta mesma transação (mesmo "cur").
        id_categoria = obter_ou_criar_categoria(cur, categoria_nome)

        codigo = gerar_codigo_produto(cur)  # sorteia um código único, verificando contra o banco
        cur.execute(
            """INSERT INTO produto (nome, codigo, id_categoria, id_fornecedor, quantidade_atual, quantidade_minima, preco_unitario)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (nome, codigo, id_categoria, id_fornecedor, quantidade_inicial, quantidade_minima, preco_unitario),
        )
        conn.commit()
        return codigo
    finally:
        # Fecha a conexão independentemente do INSERT ter dado
        # certo ou não.
        conn.close()


def listar_produtos():
    """
    Retorna todos os produtos cadastrados, ordenados por nome, já
    trazendo o NOME da categoria e do fornecedor (não apenas os
    ids), através de dois LEFT JOIN.

    Usamos LEFT JOIN (e não JOIN "normal") porque id_categoria e
    id_fornecedor podem ser NULL — um produto sem fornecedor
    definido, por exemplo, ainda deve aparecer na listagem, só
    que com fornecedor_nome vindo como None.

    Esta função não decide sozinha quais produtos estão "em
    alerta" — ela apenas devolve os dados. É a tela
    (ui/principal.py) quem compara quantidade_atual com
    quantidade_minima e decide se deve destacar a linha em
    vermelho.
    """
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT
            p.*,
            c.nome AS categoria_nome,
            f.nome AS fornecedor_nome
        FROM produto p
        LEFT JOIN categoria  c ON p.id_categoria  = c.id_categoria
        LEFT JOIN fornecedor f ON p.id_fornecedor = f.id_fornecedor
        ORDER BY p.nome
    """)
    produtos = cur.fetchall()
    conn.close()
    return produtos


def registrar_movimentacao(id_produto: int, id_usuario: int, tipo: str, quantidade: str, observacao: str = ""):
    """
    Registra uma entrada ou saída de estoque para um produto e
    atualiza a quantidade atual desse produto de acordo.

    Parâmetros:
        id_produto: identificador do produto selecionado na lista;
        id_usuario: identificador de quem está logado no sistema
                    (para saber "quem" fez a movimentação —
                    rastreabilidade);
        tipo: 'entrada' (aumenta o estoque) ou 'saida' (diminui);
        quantidade: texto digitado pelo usuário, ainda não validado;
        observacao: campo livre, opcional (ex.: "venda", "compra
                    de fornecedor X").

    Passo a passo da lógica:
    1) valida se "tipo" é um dos dois valores aceitos;
    2) valida se "quantidade" é realmente um número, usando
       validar_numero(), e garante que seja maior que zero —
       não faz sentido registrar uma movimentação de 0 ou de
       valor negativo;
    3) busca no banco a quantidade atual E o preço unitário atual
       do produto — o preço é "fotografado" neste exato momento e
       gravado junto com a movimentação (preco_unitario_momento),
       preservando o histórico de valores mesmo que o preço do
       produto seja alterado depois;
    4) se for uma SAÍDA, verifica se há saldo suficiente — o
       sistema nunca deixa o estoque ficar negativo;
    5) calcula a nova quantidade (soma se for entrada, subtrai
       se for saída);
    6) grava a nova quantidade na tabela produto E insere um
       novo registro na tabela movimentacao, dentro da MESMA
       conexão — isso garante que as duas operações fiquem
       consistentes entre si (se uma falhasse no meio, nenhuma
       das duas seria "commitada" de forma parcial, porque só
       chamamos conn.commit() depois das duas).

    Retorno:
        A nova quantidade em estoque do produto, já atualizada —
        útil caso a interface queira exibir uma confirmação com
        o saldo mais recente.
    """
    if tipo not in ("entrada", "saida"):
        raise ValueError("Tipo de movimentação inválido.")

    quantidade = int(validar_numero(quantidade, "Quantidade"))
    if quantidade <= 0:
        raise ValueError("A quantidade deve ser maior que zero.")

    conn = get_connection()
    cur = conn.cursor()
    try:
        # Busca a quantidade atual e o preço unitário vigente ANTES
        # de alterar, para poder calcular o novo saldo, validar
        # saída insuficiente e "fotografar" o preço deste instante.
        cur.execute("SELECT quantidade_atual, preco_unitario FROM produto WHERE id_produto = ?", (id_produto,))
        row = cur.fetchone()
        if row is None:
            raise ValueError("Produto não encontrado.")

        atual = row["quantidade_atual"]
        preco_momento = row["preco_unitario"]

        # Regra de negócio: não é permitido registrar uma saída
        # maior do que o que existe fisicamente em estoque.
        if tipo == "saida" and quantidade > atual:
            raise ValueError("Quantidade de saída maior que o estoque disponível.")

        # Entrada soma, saída subtrai.
        nova_qtd = atual + quantidade if tipo == "entrada" else atual - quantidade

        # Atualiza o saldo do produto...
        cur.execute("UPDATE produto SET quantidade_atual = ? WHERE id_produto = ?", (nova_qtd, id_produto))

        # ...e registra o histórico dessa movimentação, incluindo o
        # preço "congelado" no momento (preco_unitario_momento),
        # mantendo rastreabilidade de quem fez o quê, quando e a
        # qual valor (data_hora é preenchida automaticamente pelo
        # banco).
        cur.execute(
            """INSERT INTO movimentacao (id_produto, id_usuario, tipo, quantidade, preco_unitario_momento, observacao)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (id_produto, id_usuario, tipo, quantidade, preco_momento, observacao),
        )

        # Só confirma as duas alterações (UPDATE + INSERT) juntas,
        # no final, quando temos certeza de que tudo deu certo.
        conn.commit()
        return nova_qtd
    finally:
        conn.close()


def listar_movimentacoes():
    """
    Retorna o histórico completo de movimentações (entradas e
    saídas), já com o nome do produto e o nome de quem realizou
    cada movimentação — dados usados pelo relatório de
    movimentações (ver models/relatorio.py).

    Ordenado da mais recente para a mais antiga (DESC), que é a
    ordem mais útil para quem está conferindo o que aconteceu
    recentemente no estoque.
    """
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT
            m.id_movimentacao,
            p.nome AS produto_nome,
            p.codigo AS produto_codigo,
            u.nome AS usuario_nome,
            m.tipo,
            m.quantidade,
            m.preco_unitario_momento,
            m.data_hora,
            m.observacao
        FROM movimentacao m
        JOIN produto p ON m.id_produto = p.id_produto
        JOIN usuario u ON m.id_usuario = u.id_usuario
        ORDER BY m.data_hora DESC
    """)
    movimentacoes = cur.fetchall()
    conn.close()
    return movimentacoes
