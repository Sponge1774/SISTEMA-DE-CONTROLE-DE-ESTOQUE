"""
models/relatorio.py
================================================================
Geração de relatórios exportáveis do estoque, usando a biblioteca
pandas — exatamente como estudado na Unidade III da disciplina
("Exportação de Arquivos"): o pandas recebe os dados no formato
de lista de dicionários e o DataFrame os organiza automaticamente
em linhas e colunas, prontos para exportar em CSV, Excel ou JSON.

Por que pandas em vez de escrever o CSV "na mão" com o módulo csv?
- Uma única linha de código (to_csv / to_excel) já cuida de
  separadores, cabeçalho e codificação de caracteres;
- O mesmo DataFrame pode ser exportado em vários formatos
  diferentes sem reescrever a lógica de montagem dos dados;
- É a ferramenta que o mercado usa quando o relatório precisa ser
  aberto depois no Excel ou reaproveitado em outra análise.
================================================================
"""

import pandas as pd

from models.produto import listar_produtos, listar_movimentacoes


def _produtos_para_dataframe() -> pd.DataFrame:
    """
    Converte a listagem de produtos (linhas do SQLite) em um
    DataFrame do pandas.

    Cada linha do banco (sqlite3.Row) é transformada em um
    dicionário {nome_da_coluna: valor}; o pandas.DataFrame recebe
    essa LISTA DE DICIONÁRIOS e monta automaticamente a tabela
    (linhas e colunas), exatamente como descrito na Unidade III.
    """
    produtos = listar_produtos()
    linhas = [dict(p) for p in produtos]
    df = pd.DataFrame(linhas)

    if df.empty:
        return df

    # Coluna calculada: indica visualmente, no próprio relatório,
    # quais produtos estão abaixo da quantidade mínima — a mesma
    # regra usada para o destaque vermelho na tela principal.
    df["situacao"] = df.apply(
        lambda linha: "ABAIXO DO MÍNIMO" if linha["quantidade_atual"] < linha["quantidade_minima"] else "OK",
        axis=1,
    )

    # Seleciona e renomeia as colunas para nomes de leitura mais
    # amigável no relatório final (o banco usa nomes técnicos como
    # "categoria_nome"; o relatório usa "Categoria").
    df = df.rename(columns={
        "id_produto": "ID",
        "nome": "Produto",
        "codigo": "Código",
        "categoria_nome": "Categoria",
        "fornecedor_nome": "Fornecedor",
        "quantidade_atual": "Quantidade Atual",
        "quantidade_minima": "Quantidade Mínima",
        "preco_unitario": "Preço Unitário",
        "situacao": "Situação",
    })
    colunas_finais = [
        "ID", "Produto", "Código", "Categoria", "Fornecedor",
        "Quantidade Atual", "Quantidade Mínima", "Preço Unitário", "Situação",
    ]
    return df[colunas_finais]


def _movimentacoes_para_dataframe() -> pd.DataFrame:
    """
    Mesma ideia da função acima, mas para o histórico de
    movimentações (entradas e saídas).
    """
    movimentacoes = listar_movimentacoes()
    linhas = [dict(m) for m in movimentacoes]
    df = pd.DataFrame(linhas)

    if df.empty:
        return df

    df = df.rename(columns={
        "id_movimentacao": "ID",
        "produto_nome": "Produto",
        "produto_codigo": "Código",
        "usuario_nome": "Usuário",
        "tipo": "Tipo",
        "quantidade": "Quantidade",
        "preco_unitario_momento": "Preço Unitário (no momento)",
        "data_hora": "Data/Hora",
        "observacao": "Observação",
    })
    colunas_finais = [
        "ID", "Data/Hora", "Produto", "Código", "Tipo",
        "Quantidade", "Preço Unitário (no momento)", "Usuário", "Observação",
    ]
    return df[colunas_finais]


def gerar_relatorio_estoque(caminho_arquivo: str):
    """
    Gera o relatório de ESTOQUE ATUAL no formato indicado pela
    extensão do arquivo escolhido pelo usuário:
        .csv  -> df.to_csv()
        .xlsx -> df.to_excel()  (requer o pacote "openpyxl")

    Levanta ValueError se não houver nenhum produto cadastrado
    (nada para exportar) ou se a extensão do arquivo não for
    suportada.
    """
    df = _produtos_para_dataframe()
    if df.empty:
        raise ValueError("Não há produtos cadastrados para gerar o relatório.")
    _exportar_dataframe(df, caminho_arquivo)


def gerar_relatorio_movimentacoes(caminho_arquivo: str):
    """
    Gera o relatório de HISTÓRICO DE MOVIMENTAÇÕES (entradas e
    saídas), no mesmo esquema de exportação do relatório de
    estoque.
    """
    df = _movimentacoes_para_dataframe()
    if df.empty:
        raise ValueError("Não há movimentações registradas para gerar o relatório.")
    _exportar_dataframe(df, caminho_arquivo)


def _exportar_dataframe(df: pd.DataFrame, caminho_arquivo: str):
    """
    Função auxiliar que decide COMO exportar (CSV ou Excel) com
    base na extensão do caminho escolhido pelo usuário na tela.
    """
    caminho_lower = caminho_arquivo.lower()

    if caminho_lower.endswith(".csv"):
        # index=False evita que o pandas grave uma coluna extra
        # com o número da linha (0, 1, 2...); utf-8-sig garante
        # que acentos apareçam corretos ao abrir o CSV no Excel.
        df.to_csv(caminho_arquivo, index=False, encoding="utf-8-sig", sep=";")
    elif caminho_lower.endswith(".xlsx"):
        df.to_excel(caminho_arquivo, index=False, engine="openpyxl")
    else:
        raise ValueError("Formato de arquivo não suportado. Escolha .csv ou .xlsx.")
