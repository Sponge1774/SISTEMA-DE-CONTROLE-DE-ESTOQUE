"""
models/usuario.py
================================================================
Esta é a "camada de regras de negócio" (model) relacionada a
USUÁRIO. Aqui ficam as funções que sabem COMO autenticar e
cadastrar usuários — a interface gráfica (pasta ui/) apenas
chama essas funções e mostra o resultado na tela, sem conhecer
detalhes de SQL.

Separar o código dessa forma (banco / regras de negócio /
interface) é uma boa prática chamada "separação de
responsabilidades": se um dia trocarmos o Tkinter por outra
biblioteca de interface, ou o SQLite por outro banco, este
arquivo muda pouco ou nada.
================================================================
"""

from database.db import get_connection, hash_senha


def autenticar(login: str, senha: str):
    """
    Verifica se o par login/senha corresponde a um usuário
    cadastrado no banco.

    Parâmetros:
        login: texto digitado no campo "Login" da tela;
        senha: texto digitado no campo "Senha" (em texto puro).

    Retorno:
        Uma linha (sqlite3.Row) com os dados do usuário, se as
        credenciais forem válidas; ou None, caso contrário.

    Como funciona a comparação:
    Nunca comparamos a senha digitada diretamente com o que está
    no banco. Em vez disso, aplicamos hash_senha() na senha que
    o usuário acabou de digitar e comparamos o HASH resultante
    com o hash já salvo (senha_hash). Se os hashes forem iguais,
    a senha original também era igual — sem nunca precisarmos
    "descriptografar" nada (SHA-256 não é reversível).
    """
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT * FROM usuario WHERE login = ? AND senha_hash = ?",
        (login, hash_senha(senha)),
    )
    usuario = cur.fetchone()  # None se não encontrar nenhuma linha correspondente
    conn.close()
    return usuario


def cadastrar_usuario(nome: str, login: str, senha: str, perfil: str):
    """
    Insere um novo usuário no banco de dados.

    Regra de negócio importante: esta função NÃO verifica sozinha
    se quem está chamando é administrador — essa checagem é feita
    na interface (ui/principal.py), que só exibe o botão
    "Cadastrar Usuário" quando o usuário logado tem perfil
    'admin'. Ou seja, a segurança aqui é reforçada em duas camadas:
    1) a tela nem mostra a opção para quem não é admin;
    2) mesmo que alguém tentasse chamar esta função diretamente,
       o campo "perfil" só aceita 'admin' ou 'comum' por causa da
       restrição CHECK definida lá no banco (db.py).

    Validações feitas aqui:
    - nome, login e senha não podem estar vazios;
    - perfil precisa ser exatamente 'admin' ou 'comum'.
    Se alguma validação falhar, é lançada uma ValueError com uma
    mensagem amigável, que a tela captura e mostra ao usuário.
    """
    if not nome or not login or not senha:
        raise ValueError("Todos os campos são obrigatórios.")
    if perfil not in ("admin", "comum"):
        raise ValueError("Perfil inválido.")

    conn = get_connection()
    cur = conn.cursor()
    try:
        # A senha é convertida para hash ANTES de ser gravada —
        # nunca guardamos a senha original no banco.
        cur.execute(
            "INSERT INTO usuario (nome, login, senha_hash, perfil) VALUES (?, ?, ?, ?)",
            (nome, login, hash_senha(senha), perfil),
        )
        conn.commit()
    finally:
        # O bloco "finally" garante que a conexão é sempre
        # fechada, mesmo se o INSERT falhar (por exemplo, se o
        # login já existir, já que a coluna é UNIQUE). Nesse caso
        # de erro, a exceção sobe para quem chamou esta função
        # (a tela), que trata isso com uma mensagem ao usuário.
        conn.close()


def listar_usuarios():
    """
    Retorna todos os usuários cadastrados (sem o hash da senha,
    por segurança — só os dados que fazem sentido exibir em uma
    eventual tela de gerenciamento de usuários).
    """
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id_usuario, nome, login, perfil, data_cadastro FROM usuario")
    dados = cur.fetchall()
    conn.close()
    return dados
