"""
models/fornecedor.py
================================================================
Regras de negócio da entidade FORNECEDOR (nova). Diferente da
categoria, o fornecedor exige um cadastro mais completo (nome,
CNPJ e telefone), então ele é cadastrado em uma janela própria,
em vez de ser criado "na hora" a partir de um campo de texto.
================================================================
"""

from database.db import get_connection


def listar_fornecedores():
    """Retorna todos os fornecedores cadastrados, em ordem alfabética."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM fornecedor ORDER BY nome")
    dados = cur.fetchall()
    conn.close()
    return dados


def cadastrar_fornecedor(nome: str, cnpj: str, telefone: str = ""):
    """
    Cadastra um novo fornecedor.

    Validações:
    - nome e cnpj são obrigatórios;
    - o CNPJ precisa ser único no banco (restrição UNIQUE definida
      em database/db.py); se já existir, o INSERT falha e o erro é
      repassado para a tela tratar.

    Este cadastro é aberto a qualquer usuário logado (não é
    restrito ao perfil admin), pois cadastrar fornecedor é uma
    atividade operacional do dia a dia do estoque, diferente do
    cadastro de USUÁRIO do sistema, que sim é exclusivo do admin
    por questão de segurança de acesso.
    """
    if not nome or not cnpj:
        raise ValueError("Nome e CNPJ do fornecedor são obrigatórios.")

    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO fornecedor (nome, cnpj, telefone) VALUES (?, ?, ?)",
            (nome, cnpj, telefone),
        )
        conn.commit()
    finally:
        conn.close()
