-- ============================================================
-- Script SQL - Estrutura do banco de dados
-- Sistema de Controle de Estoque - Development with Python
-- Banco de dados: SQLite
-- Gerado a partir de database/db.py (funcao criar_tabelas)
-- ============================================================

-- Tabela: usuario
CREATE TABLE usuario (
            id_usuario     INTEGER PRIMARY KEY AUTOINCREMENT,
            nome           TEXT NOT NULL,
            login          TEXT NOT NULL UNIQUE,
            senha_hash     TEXT NOT NULL,
            perfil         TEXT NOT NULL CHECK (perfil IN ('admin', 'comum')),
            data_cadastro  TEXT DEFAULT CURRENT_TIMESTAMP
        );

-- Tabela: categoria
CREATE TABLE categoria (
            id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
            nome         TEXT NOT NULL UNIQUE
        );

-- Tabela: fornecedor
CREATE TABLE fornecedor (
            id_fornecedor INTEGER PRIMARY KEY AUTOINCREMENT,
            nome          TEXT NOT NULL,
            cnpj          TEXT NOT NULL UNIQUE,
            telefone      TEXT
        );

-- Tabela: produto
CREATE TABLE produto (
            id_produto        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome              TEXT NOT NULL,
            codigo            TEXT NOT NULL UNIQUE,
            id_categoria      INTEGER,
            id_fornecedor     INTEGER,
            quantidade_atual  INTEGER NOT NULL DEFAULT 0,
            quantidade_minima INTEGER NOT NULL DEFAULT 0,
            preco_unitario    NUMERIC(10,2) NOT NULL DEFAULT 0,
            FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria),
            FOREIGN KEY (id_fornecedor) REFERENCES fornecedor (id_fornecedor)
        );

-- Tabela: movimentacao
CREATE TABLE movimentacao (
            id_movimentacao      INTEGER PRIMARY KEY AUTOINCREMENT,
            id_produto            INTEGER NOT NULL,
            id_usuario             INTEGER NOT NULL,
            tipo                   TEXT NOT NULL CHECK (tipo IN ('entrada', 'saida')),
            quantidade             INTEGER NOT NULL,
            preco_unitario_momento NUMERIC(10,2) NOT NULL DEFAULT 0,
            data_hora              TEXT DEFAULT CURRENT_TIMESTAMP,
            observacao             TEXT,
            FOREIGN KEY (id_produto) REFERENCES produto (id_produto),
            FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        );

-- Usuario administrador padrao criado na primeira execucao:
-- login: admin | senha: admin123 (hash SHA-256 armazenado, nao a senha em texto puro)
