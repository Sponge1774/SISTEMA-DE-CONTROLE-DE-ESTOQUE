"""
database/db.py
================================================================
Este módulo é a "camada de banco de dados" da aplicação. Ele tem
três responsabilidades:

1. Definir ONDE o arquivo do banco SQLite fica salvo (DB_PATH);
2. Abrir conexões com esse banco (get_connection);
3. Criar as tabelas na primeira execução, se elas ainda não
   existirem (criar_tabelas).

Usamos o SQLite porque ele não exige instalação de um servidor
separado: o "banco de dados" é literalmente um único arquivo
(.db) salvo junto com o projeto, e o Python já sabe conversar
com ele através do módulo padrão `sqlite3`.

------------------------------------------------------------------
MODELAGEM (versão atualizada, com 5 tabelas):

  CATEGORIA ──┐
              │ 1:N
  FORNECEDOR ─┼──> PRODUTO ──> MOVIMENTACAO <── USUARIO
              │      (1:N)        (1:N)          (1:N)

- CATEGORIA e FORNECEDOR foram extraídas como tabelas próprias
  (normalização), em vez de texto livre dentro de PRODUTO, para
  evitar inconsistência de dados (ex.: "Ferragens" vs "ferragens")
  e permitir reaproveitar o mesmo fornecedor/categoria em vários
  produtos sem repetir informação.
- MOVIMENTACAO agora guarda também o preço unitário praticado no
  momento exato da movimentação (preco_unitario_momento), preser-
  vando o histórico de valores mesmo que o preço do produto mude
  depois — a mesma ideia usada em sistemas de vendas para não
  perder o preço "congelado" de uma transação já concluída.
------------------------------------------------------------------
"""

import sqlite3   # módulo padrão do Python para trabalhar com SQLite (não precisa instalar nada)
import hashlib   # módulo padrão usado para gerar o hash (criptografia) da senha
import os        # módulo padrão usado aqui só para montar o caminho do arquivo do banco


DB_PATH = os.path.join(os.path.dirname(__file__), "estoque.db")


def get_connection():
    """
    Abre e devolve uma conexão com o banco de dados SQLite.

    - PRAGMA foreign_keys = ON: liga a validação de chaves
      estrangeiras (desligada por padrão no SQLite), garantindo
      que um PRODUTO não referencie uma CATEGORIA ou FORNECEDOR
      inexistente, e que uma MOVIMENTACAO não referencie um
      PRODUTO ou USUARIO inexistente.
    - conn.row_factory = sqlite3.Row: permite acessar cada linha
      tanto por índice quanto por nome de coluna (linha["nome"]).
    """
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def hash_senha(senha: str) -> str:
    """
    Gera o hash SHA-256 de uma senha em texto puro, para nunca
    guardarmos a senha original no banco (requisito opcional "l.
    Criptografia de senha" do enunciado).
    """
    return hashlib.sha256(senha.encode("utf-8")).hexdigest()


def criar_tabelas():
    """
    Cria as cinco tabelas do sistema, caso ainda não existam, e
    garante que exista pelo menos um usuário administrador para
    o primeiro acesso.
    """
    conn = get_connection()
    cur = conn.cursor()

    # --------------------------------------------------------
    # Tabela USUARIO — quem pode acessar o sistema.
    # --------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuario (
            id_usuario     INTEGER PRIMARY KEY AUTOINCREMENT,
            nome           TEXT NOT NULL,
            login          TEXT NOT NULL UNIQUE,
            senha_hash     TEXT NOT NULL,
            perfil         TEXT NOT NULL CHECK (perfil IN ('admin', 'comum')),
            data_cadastro  TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # --------------------------------------------------------
    # Tabela CATEGORIA (NOVA)
    # Antes, "categoria" era um campo de texto livre dentro de
    # PRODUTO. Agora é uma entidade própria, evitando que o mesmo
    # tipo de produto seja cadastrado com grafias diferentes
    # ("Ferragens", "ferragens", "FERRAGENS...") em produtos
    # distintos — o que atrapalharia relatórios e filtros.
    # --------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS categoria (
            id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
            nome         TEXT NOT NULL UNIQUE
        )
    """)

    # --------------------------------------------------------
    # Tabela FORNECEDOR (NOVA)
    # Passa a existir como entidade própria, com CNPJ único
    # (identificador legal da empresa fornecedora), permitindo
    # relacionar vários produtos a um mesmo fornecedor.
    # --------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS fornecedor (
            id_fornecedor INTEGER PRIMARY KEY AUTOINCREMENT,
            nome          TEXT NOT NULL,
            cnpj          TEXT NOT NULL UNIQUE,
            telefone      TEXT
        )
    """)

    # --------------------------------------------------------
    # Tabela PRODUTO (ATUALIZADA)
    # - id_categoria e id_fornecedor: chaves estrangeiras que
    #   substituem o antigo campo de texto livre "categoria".
    #   Ambas aceitam NULL, pois nem todo produto precisa ter
    #   fornecedor ou categoria definidos no momento do cadastro.
    # - preco_unitario: tipo de dado NUMERIC(10,2). O SQLite não
    #   impõe rigidamente esse tipo (ele usa "type affinity"),
    #   mas declarar NUMERIC(10,2) documenta a intenção de guardar
    #   um valor monetário com 2 casas decimais, e o próprio driver
    #   Python passa a tratar esse campo com afinidade numérica,
    #   evitando comportamentos inesperados de ponto flutuante
    #   puro (tipo REAL) em cálculos financeiros.
    # --------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS produto (
            id_produto        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome              TEXT NOT NULL,
            codigo            TEXT NOT NULL UNIQUE,
            id_categoria      INTEGER,
            id_fornecedor     INTEGER,
            quantidade_atual  INTEGER NOT NULL DEFAULT 0,
            quantidade_minima INTEGER NOT NULL DEFAULT 0,
            preco_unitario    NUMERIC(10,2) NOT NULL DEFAULT 0,
            FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria),
            FOREIGN KEY (id_fornecedor) REFERENCES fornecedor (id_fornecedor)
        )
    """)

    # --------------------------------------------------------
    # Tabela MOVIMENTACAO (ATUALIZADA)
    # - preco_unitario_momento (NOVO): guarda o preço unitário do
    #   produto exatamente no instante da movimentação. Sem essa
    #   coluna, se o preço do produto fosse editado no futuro, o
    #   histórico de movimentações antigas passaria a "mentir"
    #   sobre o valor praticado naquela época. Isso é o mesmo
    #   princípio do preço histórico em notas fiscais de venda.
    # --------------------------------------------------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS movimentacao (
            id_movimentacao      INTEGER PRIMARY KEY AUTOINCREMENT,
            id_produto            INTEGER NOT NULL,
            id_usuario             INTEGER NOT NULL,
            tipo                   TEXT NOT NULL CHECK (tipo IN ('entrada', 'saida')),
            quantidade             INTEGER NOT NULL,
            preco_unitario_momento NUMERIC(10,2) NOT NULL DEFAULT 0,
            data_hora              TEXT DEFAULT CURRENT_TIMESTAMP,
            observacao             TEXT,
            FOREIGN KEY (id_produto) REFERENCES produto (id_produto),
            FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        )
    """)

    # --------------------------------------------------------
    # Usuário administrador padrão (primeira execução).
    # --------------------------------------------------------
    cur.execute("SELECT COUNT(*) AS total FROM usuario")
    if cur.fetchone()["total"] == 0:
        cur.execute(
            "INSERT INTO usuario (nome, login, senha_hash, perfil) VALUES (?, ?, ?, ?)",
            ("Administrador", "admin", hash_senha("admin123"), "admin"),
        )

    conn.commit()
    conn.close()


if __name__ == "__main__":
    criar_tabelas()
    print(f"Banco de dados criado/verificado em: {DB_PATH}")
    print("Usuário padrão -> login: admin | senha: admin123 (altere após o primeiro acesso)")
