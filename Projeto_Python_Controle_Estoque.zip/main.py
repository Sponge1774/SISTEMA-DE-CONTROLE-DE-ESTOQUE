"""
main.py
================================================================
Ponto de entrada da aplicação de Controle de Estoque.

Este arquivo é propositalmente pequeno: sua única função é
"orquestrar" a ordem de inicialização do sistema, sem conter
nenhuma regra de negócio nem nenhum componente visual próprio.
Isso segue o princípio de que cada arquivo do projeto deve ter
uma responsabilidade clara (banco de dados, regra de negócio,
interface, ou — como aqui — apenas "dar a partida" no programa).

Como executar:
    1. Tenha o Python 3 instalado (https://www.python.org/)
    2. No terminal, dentro desta pasta, execute:  python main.py
    3. Faça login com o usuário padrão: login "admin", senha "admin123"
================================================================
"""

from database.db import criar_tabelas
from ui.login import TelaLogin
from ui.principal import TelaPrincipal


def abrir_tela_principal(usuario):
    """
    Esta função é passada como "callback" para a TelaLogin (veja
    o parâmetro ao_autenticar em ui/login.py). Ela só é executada
    DEPOIS que o login foi validado com sucesso, recebendo os
    dados do usuário autenticado.

    Aqui criamos a janela principal (TelaPrincipal) e chamamos
    app.mainloop() — o "loop de eventos" do Tkinter, responsável
    por manter a janela aberta, respondendo a cliques, digitação
    etc., até que o usuário a feche.
    """
    app = TelaPrincipal(usuario)
    app.mainloop()


# ----------------------------------------------------------------
# Este bloco só roda quando executamos "python main.py"
# diretamente (e não quando este arquivo é importado por outro
# script, o que não deveria acontecer neste projeto, mas é uma
# boa prática do Python de qualquer forma).
# ----------------------------------------------------------------
if __name__ == "__main__":
    # 1) Garante que o banco de dados e as tabelas existem antes
    #    de qualquer tela ser exibida (se já existirem, esta
    #    chamada não faz nada, graças ao "CREATE TABLE IF NOT
    #    EXISTS" usado em database/db.py).
    criar_tabelas()

    # 2) Abre a tela de login. Note que passamos a FUNÇÃO
    #    abrir_tela_principal (sem executá-la agora, sem
    #    parênteses) — ela só será chamada de dentro de
    #    TelaLogin, no momento exato em que o login for validado.
    login_app = TelaLogin(ao_autenticar=abrir_tela_principal)

    # 3) Inicia o loop de eventos da tela de login. O programa
    #    "para" nesta linha até a janela de login ser fechada
    #    (seja porque o login deu certo e chamamos self.destroy()
    #    dentro dela, seja porque o usuário fechou a janela no X).
    login_app.mainloop()
