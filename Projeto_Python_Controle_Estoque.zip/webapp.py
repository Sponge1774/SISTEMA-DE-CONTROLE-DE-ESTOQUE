"""
webapp.py
================================================================
Interface WEB da aplicação de Controle de Estoque, construída com
Flask — a segunda opção de biblioteca de interface prevista no
enunciado ("g. ... tkinter / flask").

PONTO CENTRAL DESTE ARQUIVO: ele NÃO duplica nenhuma regra de
negócio. Todas as validações, todo o acesso ao banco de dados e
toda a lógica de cadastro/movimentação continuam morando
exclusivamente em models/ (os mesmos arquivos usados por
ui/principal.py no Tkinter). Este arquivo só faz o trabalho de
"tradutor": recebe requisições HTTP, chama as funções de
models/, e devolve páginas HTML.

Por que isso é importante para a sincronização desktop <-> web?
Como as duas interfaces (Tkinter e Flask) chamam as MESMAS
funções de models/, que por sua vez sempre abrem uma conexão
NOVA com o arquivo database/estoque.db a cada operação (veja
get_connection() em database/db.py), qualquer alteração feita em
uma interface fica gravada no arquivo .db imediatamente — e a
outra interface enxerga essa mudança na próxima vez que consultar
o banco (no Flask, isso acontece a cada requisição/recarregamento
de página; no Tkinter, ao clicar em "Atualizar Lista"). Não há
cache nem cópia de dados em memória entre as duas interfaces.
================================================================
"""

import os
import tempfile

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file

from database.db import criar_tabelas
from models.usuario import autenticar, cadastrar_usuario
from models.categoria import listar_categorias
from models.fornecedor import listar_fornecedores, cadastrar_fornecedor
from models.produto import cadastrar_produto, listar_produtos, registrar_movimentacao, listar_movimentacoes
from models.relatorio import gerar_relatorio_estoque, gerar_relatorio_movimentacoes

app = Flask(__name__)
# chave usada pelo Flask para assinar o cookie de sessão (login);
# em um ambiente de produção real isso viria de uma variável de
# ambiente, mas para um projeto acadêmico local um valor fixo é
# suficiente.
app.secret_key = "chave-secreta-controle-estoque-unifecaf"


# ----------------------------------------------------------------
# Pequeno "guardião" de autenticação: as rotas que exigem login
# chamam esta função no início; se não houver usuário na sessão,
# redireciona para a tela de login. Isso evita repetir a mesma
# checagem em cada rota.
# ----------------------------------------------------------------
def usuario_logado():
    return session.get("usuario_id") is not None


# ============================================================
# LOGIN / LOGOUT
# ============================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        login_digitado = request.form.get("login", "").strip()
        senha_digitada = request.form.get("senha", "")

        if not login_digitado or not senha_digitada:
            flash("Informe login e senha.", "erro")
            return render_template("login.html")

        usuario = autenticar(login_digitado, senha_digitada)
        if usuario is None:
            flash("Login ou senha inválidos.", "erro")
            return render_template("login.html")

        # Guarda os dados do usuário na sessão (equivalente ao
        # "self.usuario" que a TelaPrincipal do Tkinter guarda em
        # memória) — é assim que o Flask mantém a "sessão de
        # usuário" exigida pelo enunciado, item "j".
        session["usuario_id"] = usuario["id_usuario"]
        session["usuario_nome"] = usuario["nome"]
        session["perfil"] = usuario["perfil"]
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ============================================================
# DASHBOARD (equivalente à TelaPrincipal do Tkinter)
# ============================================================
@app.route("/")
def dashboard():
    if not usuario_logado():
        return redirect(url_for("login"))

    # listar_produtos() é chamada do zero a cada requisição — é
    # justamente isso que garante que, se um produto foi
    # cadastrado ou movimentado pelo Tkinter um segundo atrás,
    # ele já aparece aqui ao recarregar a página.
    produtos = listar_produtos()
    return render_template("dashboard.html", produtos=produtos)


# ============================================================
# PRODUTOS
# ============================================================
@app.route("/produtos/novo", methods=["GET", "POST"])
def novo_produto():
    if not usuario_logado():
        return redirect(url_for("login"))

    if request.method == "POST":
        try:
            id_fornecedor = request.form.get("id_fornecedor") or None
            codigo = cadastrar_produto(
                request.form.get("nome", "").strip(),
                request.form.get("categoria", "").strip(),
                int(id_fornecedor) if id_fornecedor else None,
                request.form.get("quantidade_inicial", ""),
                request.form.get("quantidade_minima", ""),
                request.form.get("preco_unitario", ""),
            )
            flash(f"Produto cadastrado com sucesso! Código gerado: {codigo}", "sucesso")
            return redirect(url_for("dashboard"))
        except ValueError as erro:
            flash(str(erro), "erro")
        except Exception:
            flash("Código de produto já existente ou dado inválido.", "erro")

    return render_template(
        "produto_form.html",
        categorias=listar_categorias(),
        fornecedores=listar_fornecedores(),
    )


# ============================================================
# FORNECEDORES
# ============================================================
@app.route("/fornecedores/novo", methods=["GET", "POST"])
def novo_fornecedor():
    if not usuario_logado():
        return redirect(url_for("login"))

    if request.method == "POST":
        try:
            cadastrar_fornecedor(
                request.form.get("nome", "").strip(),
                request.form.get("cnpj", "").strip(),
                request.form.get("telefone", "").strip(),
            )
            flash("Fornecedor cadastrado com sucesso.", "sucesso")
            return redirect(url_for("dashboard"))
        except ValueError as erro:
            flash(str(erro), "erro")
        except Exception:
            flash("CNPJ já cadastrado para outro fornecedor.", "erro")

    return render_template("fornecedor_form.html")


# ============================================================
# MOVIMENTAÇÃO (entrada/saída)
# ============================================================
@app.route("/movimentacao/<int:id_produto>/<tipo>", methods=["GET", "POST"])
def movimentacao(id_produto, tipo):
    if not usuario_logado():
        return redirect(url_for("login"))
    if tipo not in ("entrada", "saida"):
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        try:
            registrar_movimentacao(
                id_produto, session["usuario_id"], tipo,
                request.form.get("quantidade", ""),
                request.form.get("observacao", "").strip(),
            )
            flash("Movimentação registrada com sucesso.", "sucesso")
            return redirect(url_for("dashboard"))
        except ValueError as erro:
            flash(str(erro), "erro")

    produto = next((p for p in listar_produtos() if p["id_produto"] == id_produto), None)
    if produto is None:
        return redirect(url_for("dashboard"))
    return render_template("movimentacao_form.html", produto=produto, tipo=tipo)


# ============================================================
# USUÁRIOS (somente admin — mesma regra do Tkinter)
# ============================================================
@app.route("/usuarios/novo", methods=["GET", "POST"])
def novo_usuario():
    if not usuario_logado():
        return redirect(url_for("login"))
    if session.get("perfil") != "admin":
        flash("Apenas administradores podem cadastrar usuários.", "erro")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        try:
            cadastrar_usuario(
                request.form.get("nome", "").strip(),
                request.form.get("login", "").strip(),
                request.form.get("senha", ""),
                request.form.get("perfil", "comum"),
            )
            flash("Usuário cadastrado com sucesso.", "sucesso")
            return redirect(url_for("dashboard"))
        except ValueError as erro:
            flash(str(erro), "erro")
        except Exception:
            flash("Login já existente.", "erro")

    return render_template("usuario_form.html")


# ============================================================
# RELATÓRIOS (reaproveita models/relatorio.py, o mesmo do Tkinter)
# ============================================================
@app.route("/relatorios")
def relatorios():
    if not usuario_logado():
        return redirect(url_for("login"))
    return render_template("relatorios.html")


@app.route("/relatorios/baixar/<tipo>/<formato>")
def baixar_relatorio(tipo, formato):
    if not usuario_logado():
        return redirect(url_for("login"))

    extensao = ".csv" if formato == "csv" else ".xlsx"
    # Gera o arquivo em uma pasta temporária do sistema e o envia
    # como download — mesma função usada pelo botão "Gerar
    # Relatório" do Tkinter, só que aqui o "Salvar como..." é o
    # próprio navegador que cuida disso.
    caminho_temporario = os.path.join(tempfile.gettempdir(), f"relatorio_{tipo}{extensao}")
    try:
        if tipo == "estoque":
            gerar_relatorio_estoque(caminho_temporario)
        else:
            gerar_relatorio_movimentacoes(caminho_temporario)
        return send_file(caminho_temporario, as_attachment=True)
    except ValueError as erro:
        flash(str(erro), "erro")
        return redirect(url_for("relatorios"))


if __name__ == "__main__":
    criar_tabelas()  # garante que o banco/tabelas existem antes de aceitar requisições
    # host="0.0.0.0" permite acessar de outros dispositivos na
    # mesma rede (ex.: celular), não só de "localhost". debug=True
    # só deve ser usado em desenvolvimento (nunca em produção).
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
